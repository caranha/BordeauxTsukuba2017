return {
  {
    text = "*bip!* A weird machine beeping every two seconds. *bip!*"
  }
}