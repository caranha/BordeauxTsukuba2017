local dialog = {
	{
		text = 'Meooow.. <3'
	}
}

return dialog