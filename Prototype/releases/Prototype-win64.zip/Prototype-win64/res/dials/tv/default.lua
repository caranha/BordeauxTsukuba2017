local dialog = {
	
	{
		text = 'Wish I had a Sega Megadrive ...'
	}

}

return dialog