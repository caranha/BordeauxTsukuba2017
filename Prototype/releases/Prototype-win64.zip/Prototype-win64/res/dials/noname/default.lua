local dialog = {
	{
		text = 'Beautiful day isn\'t it ? Don\'t answer, I know I\'m right.' 
	}
}

return dialog