local dialog = {
	{
		text = 'What else ?'
	}
}

return dialog