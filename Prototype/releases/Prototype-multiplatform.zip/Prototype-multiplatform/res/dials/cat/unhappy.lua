local dialog = {
	{
		text = 'Grrrrrrr :('
	}
}

return dialog